/*
 * PAR_Parser.h
 *
 *  Created on: 22.01.2019
 *      Author: user
 */

#ifndef PAR_PARSER_H_
#define PAR_PARSER_H_

void PAR_DataReceived(char aZnak);




#endif /* PAR_PARSER_H_ */
