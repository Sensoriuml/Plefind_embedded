/*
 * HW_Hardware.h
 *
 *  Created on: 12.09.2018
 *      Author: Adam
 */

#ifndef HW_HARDWARE_H_
#define HW_HARDWARE_H_

#define HW_VERSION 2

#define HW_DIGIPOT 2 // 1 - nieadresowalny 7bit
					 // 2 - adresowalny 8bit MCP4552


uint8_t HW_StoreData(uint32_t * aBuffer, uint8_t aLength);
void 	HW_GetData	(uint32_t * aBuffer, uint8_t aLength);


uint8_t HW_ReadConfig(void);
void    HW_StoreConfig(void);


uint8_t HW_ReadConfig(void);

void 	HW_OutSendText(uint8_t *aBuffer, uint16_t aLength);




#endif /* HW_HARDWARE_H_ */
